﻿**Follow up questions**

1. **How long did you spend on the test? What would you add if you had more time?**

R: It took me approximately 4 days to complete the test. During this period, I spent time understanding the requirements, designing and implementing the proposed solutions, as well as conducting manual tests to ensure the functionality and integrity of the code.

If I had more time, I would like to implement comprehensive test coverage, including unit tests and integration tests. Unit tests would be useful for individually verifying the behavior of each component of the code, while integration tests would ensure that all parts of the system work correctly together.

1. **What was the most useful feature that was added to the latest version of your chosen language? Please include a snippet of code that shows how you've used it**

![](Aspose.Words.7dc4ce4c-9b17-4a5e-858b-17e083453fd9.001.png)

R: In this code snippet, I used the enhancement in Java 17's Switch Expressions to simplify the logic of applying promotions in a checkout system. Instead of multiple case blocks, I can now list multiple separate cases and execute the same logic for these grouped cases. This results in cleaner and easier-to-understand code.

1. **What did you find most difficult?**

R: To answer the question about what I found most challenging, I can say that representing different types of promotions for each type of product was an initial challenge. However, I quickly overcame this difficulty by creating a flexible structure to handle different types of promotions, such as percentage discounts, buy X get Y free, and price substitution based on quantity. This approach allowed for an efficient and scalable implementation of promotions in the system, ensuring that the code was easy to maintain and extend in the future.

1. **What mechanism did you put in place to track down issues in production on this code? If you didn’t put anything, write down what you could do.**

R: I implemented a robust error management strategy in the code, capturing exceptions and logging relevant details. This allows us to quickly identify and investigate any issues that occur in production.

1. **The Wiremock represents one source of information. We should be prepared to integrate with more sources. List the steps that we would need to take to add more sources of items with diferent formats and promotions.**

R: 

- **Analysis of New Sources:** Identifying and analyzing new sources of item information that we want to integrate. This may include vendor APIs, third-party systems, or internal databases.
- **Data Format Mapping:** Analyzing the data formats of the new sources and mapping them to a standard format that our system can understand and process. This may involve data transformation, parsing different structures, and data normalization.
- **Monitoring and Maintenance:** Establishing a monitoring system to track the performance and availability of integrations with the new sources of item information. Additionally, maintaining a continuous maintenance process to address any issues that may arise and ensure that the integrations remain up-to-date and functioning correctly over time.






