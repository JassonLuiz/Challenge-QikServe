package io.github.QikServe.grocerystore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroceryStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
